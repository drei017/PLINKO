// ── FIELDS.JS ─────────────────────────────────────────────────────────────────
// Manages the username/password input fields.
// Exposes: Fields.activate(), Fields.appendChar(), Fields.bksp(),
//          Fields.clear(), Fields.switchField(), Fields.panic()

const Fields = (() => {

  let activeField = 'username';

  // ── Activate a field ──────────────────────────────────────────────────────────
  function activate(f) {
    activeField = f;
    ['username', 'password'].forEach(id => {
      document.getElementById('wrap-' + id)?.classList.toggle('active', id === f);
      const tag = document.getElementById('tag-' + id);
      if (tag) tag.textContent = id === f ? '● typing here' : '';
    });
    // Reveal the plinko board on first interaction
    Plinko.setBoardVisible();
  }

  // ── Append a character to the active field ────────────────────────────────────
  function appendChar(ch) {
    const inp = document.getElementById(activeField);
    if (inp) {
      inp.value += ch;
      syncClear(activeField);
    }
  }

  // ── Backspace — 20% chance to delete TWO characters (chaos) ──────────────────
  function bksp() {
    const inp = document.getElementById(activeField);
    if (!inp) return;

    const deleteTwo = Math.random() < 0.80;
    const amount    = deleteTwo ? 2 : 1;
    inp.value       = inp.value.slice(0, -amount);
    syncClear(activeField);

    if (deleteTwo && inp.value.length >= 0) {
      // Brief visual flash on the field to signal the double-delete
      const wrap = document.getElementById('wrap-' + activeField);
      if (wrap) {
        wrap.style.borderColor = '#ef4444';
        setTimeout(() => { wrap.style.borderColor = ''; }, 300);
      }
    }
  }

  // ── Clear a specific field ────────────────────────────────────────────────────
  function clear(e, f) {
    e.stopPropagation();
    const inp = document.getElementById(f);
    if (inp) {
      inp.value = '';
      syncClear(f);
    }
  }

  // ── Sync the ✕ clear button visibility ───────────────────────────────────────
  function syncClear(f) {
    const inp = document.getElementById(f);
    const btn = document.getElementById('clr-' + f);
    if (inp && btn) btn.classList.toggle('show', inp.value.length > 0);
  }

  // ── Switch between fields ─────────────────────────────────────────────────────
  function switchField() {
    activate(activeField === 'username' ? 'password' : 'username');
  }

  // ── Panic: scramble all typed characters ──────────────────────────────────────
  function panic() {
    ['username', 'password'].forEach(id => {
      const inp = document.getElementById(id);
      if (!inp || !inp.value) return;
      // Fisher-Yates shuffle on the string characters
      const arr = inp.value.split('');
      for (let i = arr.length - 1; i > 0; i--) {
        const j  = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      inp.value = arr.join('');
      syncClear(id);
    });

    // Visual feedback: shake both input wraps
    ['username', 'password'].forEach(id => {
      const wrap = document.getElementById('wrap-' + id);
      if (!wrap) return;
      wrap.style.transition = 'transform 0.05s';
      let shakes = 0;
      const iv = setInterval(() => {
        wrap.style.transform = shakes % 2 === 0 ? 'translateX(-4px)' : 'translateX(4px)';
        shakes++;
        if (shakes > 8) { clearInterval(iv); wrap.style.transform = ''; }
      }, 50);
    });
  }

  // Block real keyboard so only the board can type
  document.addEventListener('keydown',  e => e.preventDefault());
  document.addEventListener('keypress', e => e.preventDefault());

  return { activate, appendChar, bksp, clear, switchField, panic };
})();
