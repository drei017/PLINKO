// ── MAIN.JS ───────────────────────────────────────────────────────────────────
// Wires all modules together. This is the only place inter-module
// communication is set up, keeping each module independently readable.

(function () {

  // ── Plinko land callback ───────────────────────────────────────────────────
  // When a ball lands: show popup, type character (or cursed char + hint)
  Plinko.onLand((char, slotIdx, isCursed) => {
    UI.showCongrats(char, isCursed);

    if (isCursed) {
      // Cursed ball: type a WRONG character (a random different one)
      const ALL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'.split('');
      const wrong = ALL.filter(c => c !== char);
      const badChar = wrong[Math.floor(Math.random() * wrong.length)];
      Fields.appendChar(badChar);

      // Flash the hint to tell the user to delete it
      const hint = document.getElementById('plinkoHint');
      if (hint) {
        hint.style.color = '#a855f7';
        hint.textContent = '💀 Cursed! Delete that character!';
        setTimeout(() => {
          hint.style.color = '';
          hint.textContent = 'Drop a ball — slots shuffle every time!';
        }, 2500);
      }
    } else {
      Fields.appendChar(char);
    }
  });

  // ── Init all modules ────────────────────────────────────────────────────────
  Chaos.init();

})();
