// ── PLINKO.JS ─────────────────────────────────────────────────────────────────
// Core board rendering and physics engine.
// Exposes: Plinko.init(), Plinko.drop(options), Plinko.resize(),
//          Plinko.onLand (callback setter), Plinko.setBoardVisible()

const Plinko = (() => {
  // ── DOM refs ────────────────────────────────────────────────────────────────
  const canvas = document.getElementById('c');
  const ctx    = canvas ? canvas.getContext('2d') : null;

  // ── Config ──────────────────────────────────────────────────────────────────
  const ALL_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'.split('');
  const N         = ALL_CHARS.length;
  const ROWS      = 14;
  const BALL_R    = 6;
  const PEG_R     = 5;

  // ── State ───────────────────────────────────────────────────────────────────
  let W, H, slotW;
  const slotH      = 28;
  let PEG_ROWS_DATA = [];
  let slotChars     = [...ALL_CHARS];
  let balls         = [];
  let dropping      = false;
  let animId        = null;
  let litSlot       = -1;
  let litTimer      = null;
  let boardVisible  = false;
  let slotDriftOff  = 0;
  let gravityMult   = 1;

  // Explosion particles (every 4th drop)
  let particles = [];

  // Flat barrier wall (every 5th drop) — last 3 peg rows become a solid wall
  let barrierActive = false;
  let barrierY      = 0;
  let barrierTimer  = null;

  // Callback invoked when a ball lands: onLand(char, slotIndex, isCursed)
  let onLandCb = null;

  // ── Slot colour scale ────────────────────────────────────────────────────────
  function slotColor(i) {
    const mid  = (N - 1) / 2;
    const dist = Math.abs(i - mid) / mid;
    if (dist > 0.78) return { bg: '#dc2626', text: '#fff' };
    if (dist > 0.58) return { bg: '#f97316', text: '#fff' };
    if (dist > 0.38) return { bg: '#eab308', text: '#000' };
    if (dist > 0.18) return { bg: '#facc15', text: '#000' };
    return { bg: '#fde047', text: '#000' };
  }

  // ── Resize ───────────────────────────────────────────────────────────────────
  function resize() {
    if (!canvas) return;
    const vw    = window.innerWidth;
    const vh    = window.innerHeight;
    const availW = Math.min(vw - 260 - 28 - 48, 540);
    W = Math.max(280, availW);
    H = Math.min(vh - 80, Math.round(W * 1.1));

    canvas.width        = W;
    canvas.height       = H;
    canvas.style.width  = W + 'px';
    canvas.style.height = H + 'px';

    slotW = W / N;
    buildPegs();
    drawStatic();
  }

  function buildPegs() {
    PEG_ROWS_DATA = [];
    const topPad      = 18;
    const bottomLimit = H - slotH - 14;
    const rowH        = (bottomLimit - topPad) / ROWS;
    const margin      = 14;
    const pegSpacingX = (W - margin * 2) / ROWS;

    for (let r = 0; r < ROWS; r++) {
      const count  = r + 2;
      const y      = topPad + r * rowH + rowH * 0.5;
      const rowW   = (count - 1) * pegSpacingX;
      const startX = W / 2 - rowW / 2;
      const row    = [];
      for (let c = 0; c < count; c++) {
        row.push({ x: startX + c * pegSpacingX, y });
      }
      PEG_ROWS_DATA.push(row);
    }
  }

  function allPegs() { return PEG_ROWS_DATA.flat(); }

  // ── Draw helpers ─────────────────────────────────────────────────────────────
  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.arcTo(x + w, y,     x + w, y + r,     r);
    ctx.lineTo(x + w, y + h - r);
    ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h);
    ctx.arcTo(x,     y + h, x, y + h - r,     r);
    ctx.lineTo(x, y + r);
    ctx.arcTo(x, y,         x + r, y,          r);
    ctx.closePath();
  }

  function drawPeg(x, y, glowing = false, flat = false) {
    if (flat) {
      // Barrier mode: draw as a glowing red flat diamond/square
      ctx.beginPath();
      ctx.rect(x - PEG_R, y - 3, PEG_R * 2, 6);
      ctx.shadowColor = '#ff3b3b';
      ctx.shadowBlur  = 10;
      ctx.fillStyle   = '#ff3b3b';
      ctx.fill();
      ctx.shadowBlur  = 0;
      return;
    }
    ctx.beginPath();
    ctx.arc(x, y, PEG_R, 0, Math.PI * 2);
    if (glowing) {
      ctx.shadowColor = '#facc15';
      ctx.shadowBlur  = 14;
      ctx.fillStyle   = '#ffe566';
    } else {
      ctx.fillStyle = '#c8d8e8';
    }
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  function drawSlots() {
    const y = H - slotH;
    slotChars.forEach((ch, i) => {
      // Apply drift offset (wraps around)
      const drift = slotDriftOff % W;
      const rawX  = i * slotW + drift;
      // Wrap individual slots
      const x     = ((rawX % W) + W) % W;
      const lit   = i === litSlot;
      const col   = slotColor(i);

      ctx.fillStyle = lit ? '#fff' : col.bg;
      roundRect(x + 1, y + 2, slotW - 2, slotH - 4, 3);
      ctx.fill();

      const fs = Math.max(6, Math.min(10, slotW - 2));
      ctx.fillStyle       = lit ? col.bg : col.text;
      ctx.font            = `600 ${fs}px 'Inter', sans-serif`;
      ctx.textAlign       = 'center';
      ctx.textBaseline    = 'middle';
      ctx.fillText(ch, x + slotW / 2, y + slotH / 2);
    });
  }

  function drawStatic() {
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#0d1520';
    ctx.fillRect(0, 0, W, H);

    PEG_ROWS_DATA.forEach((row, rIdx) => {
      const isBarrierRow = barrierActive && rIdx >= ROWS - 3;
      row.forEach(p => drawPeg(p.x, p.y, !!p.glowing, isBarrierRow));
    });

    // Draw barrier wall line
    if (barrierActive) {
      ctx.save();
      ctx.strokeStyle = 'rgba(255,59,59,0.5)';
      ctx.lineWidth   = 3;
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      ctx.moveTo(0, barrierY);
      ctx.lineTo(W, barrierY);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }

    drawSlots();
  }

  // ── Slot drift (Chaos) ───────────────────────────────────────────────────────
  let driftInterval = null;

  function startDrift() {
    if (driftInterval) return;
    // drift 0.15px every 30ms (slow and sinister)
    driftInterval = setInterval(() => {
      slotDriftOff += 0.15;
      if (!animId) drawStatic(); // update while idle
    }, 30);
  }

  // ── Shuffle ───────────────────────────────────────────────────────────────────
  function shuffleSlots() {
    const a = [...ALL_CHARS];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    slotChars = a;
  }

  // ── Physics loop ─────────────────────────────────────────────────────────────
  function loop() {
    update();
    render();
    if (balls.length) {
      animId = requestAnimationFrame(loop);
    } else {
      animId   = null;
      dropping = false;
      drawStatic();
    }
  }

  function update() {
    const floor   = H - slotH - BALL_R - 2;
    const gravity = 0.38 * gravityMult;

    balls.forEach(b => {
      if (b.done) return;

      b.trail.push({ x: b.x, y: b.y });
      if (b.trail.length > 12) b.trail.shift();

      b.vy += gravity + Math.random() * 0.05 * gravityMult;
      b.vx += (Math.random() - 0.5) * 0.1;
      b.vx *= 0.994;
      b.x  += b.vx * gravityMult;
      b.y  += b.vy * gravityMult;

      // Wall bounce
      if (b.x < BALL_R + 2)     { b.x = BALL_R + 2;     b.vx =  Math.abs(b.vx) * (0.4 + Math.random() * 0.4); }
      if (b.x > W - BALL_R - 2) { b.x = W - BALL_R - 2; b.vx = -Math.abs(b.vx) * (0.4 + Math.random() * 0.4); }

      // ── Barrier wall collision (5th drop) ──────────────────────────────────
      if (barrierActive && b.y + BALL_R >= barrierY && b.vy > 0) {
        b.y  = barrierY - BALL_R;
        b.vy = -Math.abs(b.vy) * (0.5 + Math.random() * 0.4);
        b.vx += (Math.random() - 0.5) * 6;
      }

      // ── Explosion trigger (every 4th drop) — explodes at mid-board ─────────
      if (b.explodeOnFloor && !b.exploded && b.y >= H * 0.45) {
        b.exploded = true;
        spawnExplosion(b.x, b.y, b.cursed);
        b.done = true;
        flashSlot(Math.floor(Math.random() * N));
        return;
      }

      // Peg collision
      allPegs().forEach((p, pIdx) => {
        // Skip collision entirely for barrier rows (already handled above as a flat wall)
        const rowIdx = PEG_ROWS_DATA.findIndex(row => row.includes(p));
        if (barrierActive && rowIdx >= ROWS - 3) return;

        // Sneezing peg check
        if (p.sneezeForce) {
          const sdx = b.x - p.x, sdy = b.y - p.y;
          const sd  = Math.sqrt(sdx * sdx + sdy * sdy);
          if (sd < 40) {
            b.vx += p.sneezeForce * (sdx / sd || 1);
            b.vy -= Math.abs(p.sneezeForce) * 0.5;
          }
          p.sneezeForce = 0;
        }

        const dx = b.x - p.x, dy = b.y - p.y;
        const d  = Math.sqrt(dx * dx + dy * dy);
        if (d < BALL_R + PEG_R + 0.5) {
          const nx = dx / d, ny = dy / d;
          b.x = p.x + nx * (BALL_R + PEG_R + 1.5);
          b.y = p.y + ny * (BALL_R + PEG_R + 1.5);

          const speed      = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
          const bounciness = 0.28 + Math.random() * 0.45;
          const chaos      = (Math.random() - 0.5) * 3.2;
          const dot        = b.vx * nx + b.vy * ny;
          const cursedKick = b.cursed ? (Math.random() < 0.5 ? -speed * 0.8 : speed * 0.8) : 0;

          b.vx = (b.vx - 2 * dot * nx) * bounciness + chaos + cursedKick;
          b.vy = Math.abs(b.vy - 2 * dot * ny) * (0.22 + Math.random() * 0.32) + 0.5;
          if (Math.random() < 0.28) b.vx += (Math.random() - 0.5) * speed;
        }
      });

      // Landed normally
      if (b.y >= floor) {
        b.done = true;
        const drift  = slotDriftOff % W;
        const adjX   = ((b.x - drift) % W + W) % W;
        const rawIdx = Math.floor(adjX / slotW);
        const idx    = Math.min(N - 1, Math.max(0, rawIdx));
        const ch     = slotChars[idx];
        flashSlot(idx);
        if (onLandCb) onLandCb(ch, idx, b.cursed);
      }
    });

    balls = balls.filter(b => !b.done);

    // Update explosion particles
    particles.forEach(p => {
      p.x  += p.vx;
      p.y  += p.vy;
      p.vy += 0.3;
      p.vx *= 0.97;
      p.life -= p.decay;
    });
    particles = particles.filter(p => p.life > 0);
  }

  function render() {
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#0d1520';
    ctx.fillRect(0, 0, W, H);

    PEG_ROWS_DATA.forEach((row, rIdx) => {
      const isBarrierRow = barrierActive && rIdx >= ROWS - 3;
      row.forEach(p => drawPeg(p.x, p.y, !!p.glowing, isBarrierRow));
    });

    // Barrier wall line
    if (barrierActive) {
      ctx.save();
      ctx.strokeStyle = 'rgba(255,59,59,0.6)';
      ctx.lineWidth   = 3;
      ctx.setLineDash([8, 6]);
      ctx.shadowColor = '#ff3b3b';
      ctx.shadowBlur  = 10;
      ctx.beginPath();
      ctx.moveTo(0, barrierY);
      ctx.lineTo(W, barrierY);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.shadowBlur = 0;
      ctx.restore();
    }

    drawSlots();

    // Explosion particles
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
      ctx.fillStyle = p.color.replace('1)', `${Math.max(0, p.life)})`);
      ctx.fill();
    });

    balls.forEach(b => {
      // Trail
      b.trail.forEach((pt, i) => {
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, BALL_R * 0.45, 0, Math.PI * 2);
        const alpha = (i / b.trail.length) * (b.cursed ? 0.35 : 0.2);
        ctx.fillStyle = b.cursed
          ? `rgba(168,85,247,${alpha})`
          : `rgba(249,115,22,${alpha})`;
        ctx.fill();
      });

      // Ball
      ctx.shadowColor = b.cursed ? '#a855f7' : '#f97316';
      ctx.shadowBlur  = 10;
      const g = ctx.createRadialGradient(b.x - 2, b.y - 2, 1, b.x, b.y, BALL_R);
      if (b.cursed) {
        g.addColorStop(0,   '#e9d5ff');
        g.addColorStop(0.5, '#a855f7');
        g.addColorStop(1,   '#6b21a8');
      } else {
        g.addColorStop(0,   '#fdba74');
        g.addColorStop(0.5, '#f97316');
        g.addColorStop(1,   '#c2410c');
      }
      ctx.beginPath();
      ctx.arc(b.x, b.y, BALL_R, 0, Math.PI * 2);
      ctx.fillStyle = g;
      ctx.fill();
      ctx.shadowBlur = 0;
    });
  }

  // ── Explosion ─────────────────────────────────────────────────────────────────
  function spawnExplosion(x, y, cursed = false) {
    const COLORS = cursed
      ? ['rgba(168,85,247,1)', 'rgba(216,180,254,1)', 'rgba(107,33,168,1)', 'rgba(255,255,255,1)']
      : ['rgba(255,100,0,1)',  'rgba(255,200,0,1)',   'rgba(255,59,59,1)',  'rgba(255,255,200,1)'];

    for (let i = 0; i < 40; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 2 + Math.random() * 9;
      particles.push({
        x, y,
        vx:    Math.cos(angle) * speed,
        vy:    Math.sin(angle) * speed - 2,
        r:     2 + Math.random() * 4,
        life:  1.0,
        decay: 0.02 + Math.random() * 0.025,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
      });
    }
    // Big shockwave ring — drawn as a short-lived large particle
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2;
      particles.push({
        x, y,
        vx:    Math.cos(angle) * 5,
        vy:    Math.sin(angle) * 5,
        r:     10,
        life:  0.8,
        decay: 0.05,
        color: cursed ? 'rgba(180,79,255,1)' : 'rgba(255,160,0,1)',
      });
    }
  }

  function flashSlot(idx) {
    if (litTimer) clearTimeout(litTimer);
    litSlot  = idx;
    litTimer = setTimeout(() => { litSlot = -1; drawStatic(); }, 750);
  }

  // ── Public API ────────────────────────────────────────────────────────────────

  /** Show the plinko board panel */
  function setBoardVisible() {
    if (boardVisible) return;
    boardVisible = true;
    const wrap = document.getElementById('plinkoWrap');
    wrap.classList.add('visible');
    // Defer resize by two frames so the browser finishes painting
    // the newly-visible element before we read its dimensions
    requestAnimationFrame(() => requestAnimationFrame(() => {
      resize();
      startDrift();
    }));
  }

  /**
   * Drop a ball.
   * @param {object} opts
   * @param {boolean} opts.cursed  — purple cursed ball
   * @param {number}  opts.gravMult — override gravity multiplier
   */
  function drop(opts = {}) {
    if (dropping) return;

    // dropCount = document.getElementById('dropCountDisplay');
    // count = dropCount.innerHTML;
    // dropCount.innerHTML = ++count;

    gravityMult = opts.gravMult ?? 1;
    shuffleSlots();
    drawStatic();
    dropping = true;

    // Safety: if a ball ever gets stuck, unlock after 8s
    setTimeout(() => { dropping = false; }, 8000);

    balls.push({
      x:             W / 2 + (Math.random() - 0.5) * 6,
      y:             BALL_R + 2,
      vx:            (Math.random() - 0.5) * 0.4,
      vy:            1.4,
      trail:         [],
      done:          false,
      cursed:        !!opts.cursed,
      explodeOnFloor: !!opts.explodeOnFloor,
      exploded:      false,
    });

    if (!animId) animId = requestAnimationFrame(loop);
  }

  /** Flip the board upside down for `duration` ms */
  function flipBoard(duration = 3000) {
    const wrap = document.getElementById('plinkoWrap');
    wrap.classList.add('flipped');
    const hint = document.getElementById('plinkoHint');
    if (hint) hint.textContent = '🙃 BOARD FLIPPED!';
    setTimeout(() => {
      wrap.classList.remove('flipped');
      if (hint) hint.textContent = 'Drop a ball — slots shuffle every time!';
    }, duration);
  }

  /** Make a random peg sneeze (blast nearby balls) */
  function sneezePeg() {
    const pegs = allPegs();
    if (!pegs.length) return;
    const p = pegs[Math.floor(Math.random() * pegs.length)];
    p.sneezeForce = 14 + Math.random() * 8;
    p.glowing     = true;
    setTimeout(() => { p.glowing = false; drawStatic(); }, 600);
  }

  /** Activate the flat barrier wall for `duration` ms (last 3 peg rows become solid) */
  function activateBarrier(duration = 2000) {
    if (barrierActive) return;
    // barrierY = y position of the first barrier row (ROWS-3)
    const topPad      = 18;
    const bottomLimit = H - slotH - 14;
    const rowH        = (bottomLimit - topPad) / ROWS;
    barrierY      = topPad + (ROWS - 3) * rowH + rowH * 0.5 - PEG_R - 4;
    barrierActive = true;
    drawStatic();

    if (barrierTimer) clearTimeout(barrierTimer);
    barrierTimer = setTimeout(() => {
      barrierActive = false;
      drawStatic();
    }, duration);
  }

  function setGravityMult(v) { gravityMult = v; }

  function onLand(cb) { onLandCb = cb; }

  // Canvas click handler
if (canvas) {
  canvas.addEventListener('click', e => {
    console.log("clicked listener.");
    if (!boardVisible) return;
    if (!W || !H) resize();
    if (!W || !H) return;
    if (dropping) return;

    const rect = canvas.getBoundingClientRect();
    const cx   = (e.clientX - rect.left) * (W / rect.width);
    const cy   = (e.clientY - rect.top)  * (H / rect.height);
    if (cy > H - slotH + 5) return;

    Chaos.handleDrop(cx);
  });
}

  return { init: resize, drop, setBoardVisible, flipBoard, sneezePeg, activateBarrier, setGravityMult, onLand, resize };
})();