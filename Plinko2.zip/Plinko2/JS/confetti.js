// ── CONFETTI.JS ───────────────────────────────────────────────────────────────
// Self-contained confetti burst system.
// Exposes: Confetti.spawn(), Confetti.tick() (internal), auto-resizes canvas.

const Confetti = (() => {
  const canvas = document.getElementById('confettiCanvas');
  const ctx    = canvas ? canvas.getContext('2d') : null;

  const COLORS = [
    '#f97316','#facc15','#22c55e','#3b82f6','#a855f7',
    '#ec4899','#06b6d4','#ef4444','#fde047','#ffffff'
  ];

  let particles = [];
  let animId    = null;

  function resize() {
    if (!canvas) return;
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  function spawn(count = 120) {
    const cx = window.innerWidth  / 2;
    const cy = window.innerHeight / 2;

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 4 + Math.random() * 10;
      const shape = Math.random() < 0.5 ? 'rect' : 'circle';

      particles.push({
        x:        cx + (Math.random() - 0.5) * 60,
        y:        cy + (Math.random() - 0.5) * 30,
        vx:       Math.cos(angle) * speed,
        vy:       Math.sin(angle) * speed - (4 + Math.random() * 5),
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.3,
        color:    COLORS[Math.floor(Math.random() * COLORS.length)],
        w:        shape === 'rect'   ? 6 + Math.random() * 6 : 0,
        h:        shape === 'rect'   ? 3 + Math.random() * 3 : 0,
        r:        shape === 'circle' ? 2 + Math.random() * 3 : 0,
        shape,
        life:     1.0,
        decay:    0.012 + Math.random() * 0.012,
        gravity:  0.25  + Math.random() * 0.15,
      });
    }

    if (!animId) animId = requestAnimationFrame(tick);
  }

  function tick() {
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    particles.forEach(p => {
      p.x  += p.vx;
      p.y  += p.vy;
      p.vy += p.gravity;
      p.vx *= 0.98;
      p.rotation += p.rotSpeed;
      p.life -= p.decay;

      ctx.save();
      ctx.globalAlpha = Math.max(0, p.life);
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      ctx.fillStyle = p.color;

      if (p.shape === 'rect') {
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });

    particles = particles.filter(p => p.life > 0 && p.y < canvas.height + 40);

    if (particles.length > 0) {
      animId = requestAnimationFrame(tick);
    } else {
      animId = null;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  }

  return { spawn };
})();
