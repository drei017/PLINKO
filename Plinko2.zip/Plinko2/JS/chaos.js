// ── CHAOS.JS ──────────────────────────────────────────────────────────────────
const Chaos = (() => {

  let dropCount    = document.getElementById('dropCountDisplay').innerHTML;
  let heartbeatInt = null;
  let pageOpenTime = Date.now();
  let shakeTimer   = null;

  // ── Gambling promo popups ─────────────────────────────────────────────────────
  const SITES = [
    'https://www.okbet.com/?inviteCode=cas1&gad_source=1&gad_campaignid=22732954743&gbraid=0AAAAA-GeQxtUE6ODeDuCtfdbJvHoQAa7P&gclid=CjwKCAiA2PrMBhA4EiwAwpHyCzZ8AzGY9u8rdl87yhdg1M3_YShgH8V2EeBgCLCrjw3-tOGEK-q7exoCsTYQAvD_BwE',
    'https://www.pesomaxfun.com/',
    'https://www.km88a9.com/',
    'https://1xlite-42003.bar/en',
  ];

  const PROMOS = [
    {
      type: 'promo-gold',
      emoji: '💰',
      headline: 'DEPOSIT NOW — GET 16,500x!',
      body: 'First deposit of ANY amount gets multiplied 16,500 times. Guaranteed*\n\n*not guaranteed',
      cta: '💸 DEPOSIT NOW',
      url: SITES[0],
    },
    {
      type: 'promo-green',
      emoji: '🎰',
      headline: '99.9% PAYOUT RATE!',
      body: 'Our slots have the highest payout in the galaxy. The house almost never wins here. Almost.',
      cta: '🤑 SPIN NOW',
      url: SITES[1],
    },
    {
      type: 'promo-purple',
      emoji: '💎',
      headline: 'VIP ROOM UNLOCKED',
      body: 'You\'ve been selected for our exclusive VIP room. Minimum buy-in just $1. Win up to $4,000,000.',
      cta: '👑 ENTER VIP',
      url: SITES[2],
    },
    {
      type: 'promo-red',
      emoji: '🔥',
      headline: 'LIMITED TIME ONLY!',
      body: 'Next 3 minutes: every bet is secretly doubled by us. No catch. Completely real.',
      cta: '⚡ CLAIM NOW',
      url: SITES[3],
    },
    {
      type: 'promo-gold',
      emoji: '🍀',
      headline: 'LUCKY HOUR IS NOW',
      body: 'Between 12:00am and 11:59pm today only — ALL JACKPOTS TRIPLED. Today only (every day).',
      cta: '🎲 PLAY NOW',
      url: SITES[0],
    },
    {
      type: 'promo-green',
      emoji: '🏆',
      headline: 'YOU\'RE A WINNER!',
      body: 'Congratulations! You\'ve been pre-selected as a winner. Just deposit $5 to collect your $50,000 prize.',
      cta: '✅ COLLECT PRIZE',
      url: SITES[1],
    },
    {
      type: 'promo-purple',
      emoji: '🌙',
      headline: 'MIDNIGHT MADNESS',
      body: 'It\'s always midnight somewhere. That means it\'s always Midnight Madness. 10x on all bets right now.',
      cta: '🎉 GO WILD',
      url: SITES[2],
    },
    {
      type: 'promo-red',
      emoji: '🚨',
      headline: 'JACKPOT OVERFLOW!',
      body: 'Our jackpot pool is so full it\'s leaking. We NEED someone to win it. Could be you.',
      cta: '💥 TAKE IT',
      url: SITES[3],
    },
    {
      type: 'promo-gold',
      emoji: '👑',
      headline: 'ROYAL FLUSH PROMO',
      body: 'Deposit $10 and if you don\'t win $10,000 within 24 hours, we\'ll give you a coupon.',
      cta: '🃏 PLAY ROYAL',
      url: SITES[0],
    },
    {
      type: 'promo-green',
      emoji: '🤑',
      headline: 'FREE MONEY INSIDE',
      body: 'We\'re literally giving away money. Sign up now and receive 0 to $1,000,000 completely free.',
      cta: '💵 GET FREE $$$',
      url: SITES[1],
    },
  ];

  let activePopups = [];
  let promoInterval = null;

  function spawnPromo() {
    const container = document.getElementById('promoContainer');
    if (!container) return;
    if (activePopups.length >= 4) return; // max 4 at once

    const promo = PROMOS[Math.floor(Math.random() * PROMOS.length)];
    const popup = document.createElement('div');
    popup.className = `promo-popup ${promo.type}`;

    // Random position on screen edges/corners area
    const positions = [
      { top: '8%',  left: '2%'  },
      { top: '8%',  right: '2%' },
      { bottom: '12%', left: '2%'  },
      { bottom: '12%', right: '2%' },
      { top: '35%', left: '1%'  },
      { top: '35%', right: '1%' },
    ];
    const pos = positions[Math.floor(Math.random() * positions.length)];
    Object.assign(popup.style, pos);

    popup.innerHTML = `
      <button class="promo-close" onclick="this.parentElement.remove()">✕</button>
      <span class="promo-emoji">${promo.emoji}</span>
      <div class="promo-headline">${promo.headline}</div>
      <div class="promo-body">${promo.body}</div>
      <a class="promo-cta" href="${promo.url}" target="_blank" rel="noopener">${promo.cta}</a>
    `;

    // Make draggable
    makeDraggable(popup);

    container.appendChild(popup);
    activePopups.push(popup);

    // Auto-remove after 12 seconds
    setTimeout(() => {
      popup.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      popup.style.opacity = '0';
      popup.style.transform = 'scale(0.8) rotate(5deg)';
      setTimeout(() => {
        popup.remove();
        activePopups = activePopups.filter(p => p !== popup);
      }, 500);
    }, 12000);
  }

  function makeDraggable(el) {
    let startX, startY, startLeft, startTop;
    el.addEventListener('mousedown', e => {
      if (e.target.classList.contains('promo-close') || e.target.classList.contains('promo-cta')) return;
      startX = e.clientX;
      startY = e.clientY;
      const rect = el.getBoundingClientRect();
      startLeft = rect.left;
      startTop  = rect.top;
      el.style.cursor = 'grabbing';
      el.style.right = 'auto';
      el.style.bottom = 'auto';

      const onMove = e => {
        el.style.left = (startLeft + e.clientX - startX) + 'px';
        el.style.top  = (startTop  + e.clientY - startY) + 'px';
      };
      const onUp = () => {
        el.style.cursor = 'grab';
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  function startPromos() {
    // First one after 3 seconds
    setTimeout(spawnPromo, 3000);
    // Then every 6-10 seconds
    promoInterval = setInterval(() => {
      spawnPromo();
    }, 7000 + Math.random() * 3000);
  }

  // ── Jackpot counter ───────────────────────────────────────────────────────────
  function startJackpotCounters() {
    let jackpot = 1247893;
    setInterval(() => {
      jackpot += Math.floor(Math.random() * 47 + 3);
      const fmt = '$' + jackpot.toLocaleString();
      const el1 = document.getElementById('jackpotMini');
      const el2 = document.getElementById('jackpotDisplay');
      if (el1) el1.textContent = 'JACKPOT ' + fmt;
      if (el2) el2.textContent = fmt;
    }, 800);
  }

  // ── Welcome screen balance counter ───────────────────────────────────────────
  function startBalanceCounter() {
    const el = document.getElementById('balAmount');
    if (!el) return;
    let bal = 0;
    const target = 10000 + Math.random() * 990000;
    const step = target / 60;
    const iv = setInterval(() => {
      bal = Math.min(bal + step + Math.random() * step, target);
      el.textContent = '$' + bal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      if (bal >= target) clearInterval(iv);
    }, 30);
  }

  // ── Heartbeat ─────────────────────────────────────────────────────────────────
  function startHeartbeat() {
    let phase = 0;
    heartbeatInt = setInterval(() => {
      const elapsed  = (Date.now() - pageOpenTime) / 1000;
      const strength = Math.min(elapsed / 90, 1);
      const pulse    = Math.sin(phase) * 0.5 + 0.5;
      phase += 0.08;
      const r = Math.round(5  + pulse * strength * 20);
      const g = Math.round(10 + pulse * strength * 4);
      const b = Math.round(15 + pulse * strength * 8);
      document.body.style.backgroundColor = `rgb(${r},${g},${b})`;
    }, 30);
  }

  // ── Frustration shake ─────────────────────────────────────────────────────────
  function startFrustrationShake() {
    shakeTimer = setInterval(() => {
      const card = document.getElementById('loginCard');
      if (!card) return;
      card.classList.remove('shake');
      void card.offsetWidth;
      card.classList.add('shake');
      card.addEventListener('animationend', () => card.classList.remove('shake'), { once: true });
    }, 45_000);
  }

  // ── Wrong password ────────────────────────────────────────────────────────────
  function onWrongPassword() {
    const flash = document.getElementById('redFlash');
    if (flash) {
      flash.classList.add('active');
      setTimeout(() => flash.classList.remove('active'), 600);
    }
    const card = document.getElementById('loginCard');
    if (card) {
      card.classList.remove('ragequit');
      void card.offsetWidth;
      card.classList.add('ragequit');
      card.addEventListener('animationend', () => card.classList.remove('ragequit'), { once: true });
    }
    // Spawn an extra promo to rub it in
    setTimeout(spawnPromo, 400);
  }

  // ── Runaway submit button ─────────────────────────────────────────────────────
  function initRunawayButton() {
    const btn  = document.getElementById('submitBtn');
    const card = document.getElementById('loginCard');
    if (!btn || !card) return;

    let hoverTimer = null;
    let runCount   = 0;

    btn.addEventListener('mouseenter', () => {
      hoverTimer = setTimeout(() => {
        if (runCount >= 6) {
          btn.style.position = '';
          btn.style.left = '';
          btn.style.top  = '';
          btn.style.width = '';
          return;
        }
        runCount++;
        const cardRect = card.getBoundingClientRect();
        const btnRect  = btn.getBoundingClientRect();
        const maxX = cardRect.width  - btnRect.width  - 20;
        const maxY = cardRect.height - btnRect.height - 20;
        btn.style.position   = 'absolute';
        btn.style.left       = (10 + Math.random() * maxX) + 'px';
        btn.style.top        = (10 + Math.random() * maxY) + 'px';
        btn.style.width      = btnRect.width + 'px';
        btn.style.transition = 'left 0.2s, top 0.2s';
      }, 500);
    });

    btn.addEventListener('mouseleave', () => clearTimeout(hoverTimer));
  }

  // ── Fake loader ───────────────────────────────────────────────────────────────
  const LOADER_MSGS = [
    'Verifying your questionable choices...',
    'Counting your remaining dignity...',
    'Consulting the plinko gods...',
    'Checking if you\'re a whale...',
    'Buffering your luck stat...',
    'Running background credit check...',
    'Calculating your losses...',
    'Asking the magic ball...',
    'Warming up the jackpot...',
    'Rigging the algorithm in your favor...',
  ];

  function initFakeLoader() {
    const btn    = document.getElementById('submitBtn');
    const loader = document.getElementById('fakeLoader');
    const bar    = document.getElementById('fakeLoaderBar');
    const msg    = document.getElementById('fakeLoaderMsg');
    if (!btn || !loader) return;

    let loaderTimer = null;
    let progressInt = null;
    let pct         = 0;

    function startLoader() {
      pct = 0;
      loader.classList.add('visible');
      msg.textContent = LOADER_MSGS[Math.floor(Math.random() * LOADER_MSGS.length)];
      bar.style.setProperty('--bar-pct', '0%');
      progressInt = setInterval(() => {
        if (pct < 60)      pct += 4 + Math.random() * 5;
        else if (pct < 85) pct += 0.5 + Math.random() * 0.8;
        else if (pct < 95) pct += 0.1;
        bar.style.setProperty('--bar-pct', Math.min(pct, 97) + '%');
        if (Math.random() < 0.02) {
          msg.textContent = LOADER_MSGS[Math.floor(Math.random() * LOADER_MSGS.length)];
        }
      }, 80);
    }

    function stopLoader() {
      clearInterval(progressInt);
      loader.classList.remove('visible');
      pct = 0;
      bar.style.setProperty('--bar-pct', '0%');
    }

    btn.addEventListener('mouseenter', () => { loaderTimer = setTimeout(startLoader, 700); });
    btn.addEventListener('mouseleave', () => { clearTimeout(loaderTimer); stopLoader(); });
  }

  // ── Drop handler ──────────────────────────────────────────────────────────────
  const DROP_BONUSES = [
    '🎰 JACKPOT CHANCE!', '💸 2x MULTIPLIER!', '🔥 HOT DROP!',
    '⭐ LUCKY SPIN!', '💎 DIAMOND DROP!', '🍀 LUCKY BALL!',
  ];

  function handleDrop(clickX) {
    dropCount++;
    console.log("Drop Handled");

    // Update drop counter display
    const counterEl = document.getElementById('dropCountDisplay');
    if (counterEl) counterEl.textContent = dropCount;

    // Random bonus label
    if (Math.random() < 0.4) {
      const bonusEl = document.getElementById('dropBonus');
      if (bonusEl) {
        bonusEl.textContent = DROP_BONUSES[Math.floor(Math.random() * DROP_BONUSES.length)];
        bonusEl.style.animation = 'none';
        void bonusEl.offsetWidth;
        bonusEl.style.animation = 'bonusPop 0.4s ease';
        setTimeout(() => { bonusEl.textContent = ''; }, 2500);
      }
    }

    const hint = document.getElementById('plinkoHint');

    // Every 5th drop: flip the board
    if (dropCount % 5 === 0) {
      Plinko.flipBoard(3500);
      if (hint) {
        hint.textContent = '🙃 BOARD FLIPPED — CHAOS MODE!';
        setTimeout(() => { hint.textContent = '🎯 Drop a ball to type a character!'; }, 3600);
      }
    }

    // Every 4th drop: exploding ball
    const explodeOnFloor = dropCount % 4 === 0;
    if (explodeOnFloor && hint) {
      hint.style.color = '#f5c842';
      hint.textContent = '💥 EXPLOSIVE BALL INCOMING!';
      setTimeout(() => { hint.style.color = ''; hint.textContent = '🎯 Drop a ball to type a character!'; }, 2000);
    }

    // Every 5th drop: activate barrier wall for 2 seconds
    if (dropCount % 5 === 0) {
      Plinko.activateBarrier(2000);
      if (hint && !explodeOnFloor) {
        hint.style.color = '#ff3b3b';
        hint.textContent = '🧱 BARRIER WALL ACTIVE — 2 SECONDS!';
        setTimeout(() => { hint.style.color = ''; hint.textContent = '🎯 Drop a ball to type a character!'; }, 2200);
      }
    }

    // Every 4th drop or 20% chance: slow motion
    const slowmo = dropCount % 8 === 0 || Math.random() < 0.2;
    const gravMult = slowmo ? 0.28 : 1;
    if (slowmo && hint && dropCount % 5 !== 0) {
      hint.textContent = '🐌 SLOW MOTION ACTIVATED...';
      setTimeout(() => { hint.textContent = '🎯 Drop a ball to type a character!'; }, 4000);
    }

    // Every 3rd drop: cursed ball
    const cursed = dropCount % 3 === 0;
    if (cursed && hint) {
      hint.style.color = '#b44fff';
      hint.textContent = '💀 CURSED BALL INCOMING!';
      setTimeout(() => {
        hint.style.color = '';
        hint.textContent = '🎯 Drop a ball to type a character!';
      }, 500);
    }

    Plinko.drop({ cursed, gravMult, explodeOnFloor });

    // Every 6th drop: sneeze 1–3 pegs
    if (dropCount % 6 === 0) {
      const times = 1 + Math.ceil(Math.random() * 2);
      for (let i = 0; i < times; i++) {
        setTimeout(() => Plinko.sneezePeg(), 300 + i * 500 + Math.random() * 300);
      }
      if (hint) {
        setTimeout(() => {
          hint.style.color = '#f5c842';
          hint.textContent = '🤧 THE PEGS ARE SNEEZING!';
          setTimeout(() => {
            hint.style.color = '';
            hint.textContent = '🎯 Drop a ball to type a character!';
          }, 2000);
        }, 200);
      }
    }

    // Every 10th drop: spawn a bonus promo
    if (dropCount % 10 === 0) {
      setTimeout(spawnPromo, 600);
    }

    // Green flash on normal drops occasionally
    if (!cursed && Math.random() < 0.15) {
      const gflash = document.getElementById('greenFlash');
      if (gflash) {
        gflash.classList.add('active');
        setTimeout(() => gflash.classList.remove('active'), 300);
      }
    }
  }

  // ── Init ──────────────────────────────────────────────────────────────────────
  function init() {
    startHeartbeat();
    startFrustrationShake();
    initRunawayButton();
    initFakeLoader();
    startPromos();
    startJackpotCounters();
    startBalanceCounter();

    if (document.getElementById('errorMsg')) {
      setTimeout(onWrongPassword, 150);
    }
  }

  return { init, handleDrop, onWrongPassword };
})();