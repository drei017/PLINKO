// ── UI.JS ─────────────────────────────────────────────────────────────────────
const UI = (() => {

  const MESSAGES = [
    'YOU GOT', 'JACKPOT!', 'WINNER!', 'SCORED', 'NAILED IT', 'TYPED', 'CAPTURED'
  ];
  const CURSED_MESSAGES = [
    '😈 CURSED!', '💀 HEXED!', '🔮 JINXED!', '👻 WRONG ONE!', '🤡 OOPS...'
  ];
  const MULTIPLIERS = ['×1', '×2', '×5', '×10', '×100', '×1000'];

  let congratsTimer = null;

  function showCongrats(ch, isCursed = false) {
    const bubble  = document.getElementById('congratsBubble');
    const textEl  = document.getElementById('congratsText');
    const charEl  = document.getElementById('congratsChar');
    const multEl  = document.getElementById('congratsMult');
    const subEl   = document.getElementById('congratsSub');
    if (!bubble) return;

    if (isCursed) {
      const msg = CURSED_MESSAGES[Math.floor(Math.random() * CURSED_MESSAGES.length)];
      textEl.textContent = msg;
      charEl.textContent = ch;
      charEl.style.color = '#b44fff';
      charEl.style.textShadow = '0 0 30px rgba(180,79,255,0.7)';
      multEl.textContent = '×0';
      multEl.style.color = '#ff3b3b';
      subEl.textContent  = 'wrong char — delete it!';
    } else {
      const msg  = MESSAGES[Math.floor(Math.random() * MESSAGES.length)];
      const mult = MULTIPLIERS[Math.floor(Math.random() * MULTIPLIERS.length)];
      textEl.textContent = msg;
      charEl.textContent = ch;
      charEl.style.color = '#ffe566';
      charEl.style.textShadow = '0 0 30px rgba(245,200,66,0.7)';
      multEl.textContent = mult;
      multEl.style.color = mult === '×1' ? '#4a7a9b' : '#00e676';
      subEl.textContent  = 'added to your input';
    }

    bubble.classList.remove('show');
    void bubble.offsetWidth;
    bubble.classList.add('show');

    if (!isCursed) Confetti.spawn();

    if (congratsTimer) clearTimeout(congratsTimer);
    congratsTimer = setTimeout(() => bubble.classList.remove('show'), 2000);
  }

  return { showCongrats };
})();
