<?php
session_start();

$users = [
    'admin'   => ['password' => 'pass123',  'avatar' => '🎰', 'title' => 'High Roller'],
    'user1'   => ['password' => 'hello456', 'avatar' => '🃏', 'title' => 'Card Shark'],
    'bigwins' => ['password' => 'money999', 'avatar' => '💰', 'title' => 'Whale'],
    'lucky7'  => ['password' => 'lucky777', 'avatar' => '🍀', 'title' => 'Lucky Charm'],
    'dealer'  => ['password' => 'house000', 'avatar' => '🎲', 'title' => 'The House'],
];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    if ($u !== '' && $p !== '') {
        if (isset($users[$u]) && $users[$u]['password'] === $p) {
            $_SESSION['user']   = $u;
            $_SESSION['avatar'] = $users[$u]['avatar'];
            $_SESSION['title']  = $users[$u]['title'];
        } else {
            $error = 'Wrong credentials! The house always wins... try again.';
        }
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$loggedIn = isset($_SESSION['user']);
$username = $loggedIn ? htmlspecialchars($_SESSION['user']) : '';
$avatar   = $loggedIn ? htmlspecialchars($_SESSION['avatar']) : '';
$title    = $loggedIn ? htmlspecialchars($_SESSION['title']) : '';
$savedInput = htmlspecialchars($_POST['username'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>🎰 ThisIsNotGambling — Premium Plinko Casino Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Oswald:wght@400;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- Ambient casino background elements -->
<div class="casino-bg">
  <div class="bg-reel" id="bgReel"></div>
  <div class="scanlines"></div>
  <div class="vignette"></div>
</div>

<?php if ($loggedIn): ?>

  <!-- ── FAKE BSOD OVERLAY ── -->
  <div id="bsodOverlay">

    <!-- Stage 1: Windows BSOD -->
    <div id="bsodScreen">
      <div class="bsod-face">:(</div>
      <div class="bsod-title">Your PC ran into a problem and needs to restart.</div>
      <div class="bsod-msg">We're just collecting some error info, and then we'll restart for you.</div>
      <div class="bsod-pct"><span id="bsodPct">0</span>% complete</div>
      <div class="bsod-code">
        For more information about this issue and possible fixes, visit<br>
        <strong>https://www.windows.com/stopcode</strong><br><br>
        Stop code: <strong>JACKPOT_OVERFLOW_EXCEPTION</strong><br>
        What failed: <strong>casino.exe</strong>
      </div>
      <div class="bsod-qr">⬛⬜⬛<br>⬜⬛⬜<br>⬛⬜⬛</div>
    </div>

    <!-- Stage 2: Shutdown screen -->
    <div id="shutdownScreen">
      <div class="shutdown-logo">⊞</div>
      <div class="shutdown-text">Shutting down...</div>
      <div class="shutdown-spinner">
        <div class="ss-dot"></div>
        <div class="ss-dot"></div>
        <div class="ss-dot"></div>
        <div class="ss-dot"></div>
        <div class="ss-dot"></div>
      </div>
    </div>

    <!-- Stage 3: Black screen -->
    <div id="blackScreen">
      <div class="black-cursor">_</div>
    </div>

    <!-- Stage 4: Just kidding -->
    <div id="jkScreen">
      <div class="jk-emoji">😂</div>
      <div class="jk-title">JUST KIDDING!</div>
      <div class="jk-sub">Your laptop is fine. You didn't win anything either.</div>
      <button class="jk-btn" onclick="document.getElementById('bsodOverlay').style.display='none'">OK fine 😭</button>
    </div>

  </div>

  <div class="welcome-wrap">
    <div class="welcome-card">
      <div class="welcome-glow"></div>
      <div class="welcome-badge"><?= $avatar ?></div>
      <div class="welcome-title">WELCOME BACK</div>
      <div class="welcome-name"><?= $username ?></div>
      <div class="welcome-rank"><?= $title ?></div>
      <div class="welcome-balance">
        <span class="bal-label">BALANCE</span>
        <span class="bal-amount" id="balAmount">$0.00</span>
      </div>
      <div class="welcome-jackpot">
        <span class="jackpot-label">🎰 JACKPOT</span>
        <span class="jackpot-amount" id="jackpotDisplay">$1,247,893</span>
      </div>

      <button class="claim-btn" id="claimBtn" onclick="triggerBSOD()">
        <span class="claim-shine"></span>
        <span class="claim-icon">💰</span>
        <span class="claim-text">CLAIM JACKPOT</span>
        <span class="claim-mult">×50 MULTIPLIER</span>
      </button>

      <a class="logout-btn" href="?logout=1">← CASH OUT & LEAVE</a>
    </div>
  </div>

  <script>
  function triggerBSOD() {
    const overlay   = document.getElementById('bsodOverlay');
    const bsod      = document.getElementById('bsodScreen');
    const shutdown  = document.getElementById('shutdownScreen');
    const blackScr  = document.getElementById('blackScreen');
    const jk        = document.getElementById('jkScreen');
    const pctEl     = document.getElementById('bsodPct');
    const claimBtn  = document.getElementById('claimBtn');

    // Disable button
    claimBtn.disabled = true;
    claimBtn.style.opacity = '0.5';

    // Show overlay — start with BSOD
    overlay.style.display = 'flex';
    bsod.style.display     = 'flex';
    shutdown.style.display = 'none';
    blackScr.style.display = 'none';
    jk.style.display       = 'none';

    // Animate percentage 0 → 100 over ~4 seconds
    let pct = 0;
    const pctInterval = setInterval(() => {
      pct += 1 + Math.floor(Math.random() * 3);
      if (pct >= 100) { pct = 100; clearInterval(pctInterval); }
      pctEl.textContent = pct;
    }, 60);

    // After 5s: switch to shutdown screen
    setTimeout(() => {
      bsod.style.display     = 'none';
      shutdown.style.display = 'flex';
    }, 5000);

    // After 7s: black screen
    setTimeout(() => {
      shutdown.style.display = 'none';
      blackScr.style.display = 'flex';
    }, 7000);

    // After 9s: just kidding
    setTimeout(() => {
      blackScr.style.display = 'none';
      jk.style.display       = 'flex';
      claimBtn.disabled      = false;
      claimBtn.style.opacity = '1';
    }, 9000);
  }
  </script>

<?php else: ?>

  <!-- ── PROMO POPUPS CONTAINER ── -->
  <div id="promoContainer"></div>

  <!-- ── TICKER ── -->
  <div class="ticker-wrap">
    <div class="ticker-inner" id="tickerInner">
      🎰 JACKPOT: $1,247,893 &nbsp;|&nbsp; 🔥 PlayerX just won $47,200 &nbsp;|&nbsp; 💎 DEPOSIT NOW — GET 16,500x RETURNS &nbsp;|&nbsp; 🃏 NEW: Quantum Slots LIVE &nbsp;|&nbsp; ⚡ EXCLUSIVE: First deposit TRIPLED &nbsp;|&nbsp; 🍀 Lucky Hour starts NOW — 99% payout &nbsp;|&nbsp; 💰 VIP ROOM OPEN — invite only &nbsp;|&nbsp; 🎲 PLINKBET — Where winners are made &nbsp;|&nbsp; 🔔 SunshineKing withdrew $82,400 &nbsp;|&nbsp; ⭐ TOP RATED casino 47 years running &nbsp;|&nbsp;
    </div>
  </div>

  <!-- ── MAIN LAYOUT ── -->
  <div class="main-layout">

    <!-- ── LOGIN CARD ── -->
    <div class="login-card" id="loginCard">

      <div class="card-header">
        <div class="logo-wrap">
          <span class="logo-icon">🎰</span>
          <div class="logo-text">
            <span class="logo-main">UMindanao LIC</span>
            <span class="logo-sub">UM BBL & LIC Inside</span>
          </div>
        </div>
        <div class="jackpot-mini" id="jackpotMini">JACKPOT $1,247,893</div>
      </div>

      <?php if ($error): ?>
        <div class="err" id="errorMsg">
          <span class="err-icon">💸</span> <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form method="POST" id="loginForm" style="display:contents">

        <div class="field-block">
          <div class="field-label">🎭 PLAYER ID</div>
          <div class="inp-wrap active" id="wrap-username" onclick="Fields.activate('username')">
            <span class="inp-icon">👤</span>
            <input type="text" id="username" name="username" readonly placeholder="Enter your player ID"
              value="<?= $savedInput ?>">
            <button type="button" class="clr-btn" id="clr-username"
              onclick="Fields.clear(event,'username')">✕</button>
          </div>
          <div class="active-tag" id="tag-username">● click a field to open the plinko board</div>
        </div>

        <div class="field-block">
          <div class="field-label">🔐 SECRET PIN</div>
          <div class="inp-wrap" id="wrap-password" onclick="Fields.activate('password')">
            <span class="inp-icon">🔑</span>
            <input type="password" id="password" name="password" readonly placeholder="Your secret pin">
            <button type="button" class="clr-btn" id="clr-password"
              onclick="Fields.clear(event,'password')">✕</button>
          </div>
          <div class="active-tag" id="tag-password"></div>
        </div>

        <div class="divider">
          <span class="divider-text">USE THE BOARD TO TYPE</span>
        </div>

        <div class="fake-loader" id="fakeLoader">
          <div class="fake-loader-bar" id="fakeLoaderBar"></div>
          <div class="fake-loader-msg" id="fakeLoaderMsg"></div>
        </div>

        <button type="submit" class="submit-btn" id="submitBtn">
          <span class="btn-icon">🎰</span>
          <span class="btn-text">SPIN TO LOGIN</span>
          <span class="btn-shine"></span>
        </button>

        <div class="row-btns">
          <button type="button" class="sec-btn switch-btn" onclick="Fields.switchField()">⇄ SWITCH</button>
          <button type="button" class="sec-btn del-btn"    onclick="Fields.bksp()">⌫ DELETE</button>
          <button type="button" class="sec-btn panic-btn"  onclick="Fields.panic()">😱 PANIC</button>
        </div>

      </form>

      <div class="hint-block">
        <div class="hint-title">🎮 DEMO ACCOUNTS</div>
        <div class="hint-grid">
          <div class="hint-row"><span class="hint-user">admin</span><span class="hint-sep">/</span><span class="hint-pass">pass123</span></div>
          <div class="hint-row"><span class="hint-user">user1</span><span class="hint-sep">/</span><span class="hint-pass">hello456</span></div>
          <div class="hint-row"><span class="hint-user">lucky7</span><span class="hint-sep">/</span><span class="hint-pass">lucky777</span></div>
        </div>
      </div>

      <div class="responsible-tag">🔞 18+ ONLY — PLAY RESPONSIBLY — NOT REAL MONEY</div>

    </div><!-- /.login-card -->

    <!-- ── PLINKO BOARD ── -->
    <div class="plinko-wrap" id="plinkoWrap">
      <div class="plinko-header">
        <div class="plinko-title">PLINKO KEYBOARD</div>
        <div class="plinko-hint" id="plinkoHint">🎯 Drop a ball to type a character!</div>
      </div>
      <canvas id="c"></canvas>
      <div class="plinko-footer">
        <span class="drop-counter">DROPS: <strong id="dropCountDisplay">0</strong></span>
        <span class="drop-bonus" id="dropBonus"></span>
      </div>
    </div>

  </div><!-- /.main-layout -->

  <!-- ── OVERLAYS ── -->
  <canvas id="confettiCanvas"></canvas>
  <div id="redFlash"></div>
  <div id="greenFlash"></div>

  <div class="congrats-overlay">
    <div class="congrats-bubble" id="congratsBubble">
      <div class="congrats-text"  id="congratsText">YOU GOT</div>
      <div class="congrats-char"  id="congratsChar">A</div>
      <div class="congrats-mult"  id="congratsMult">×1</div>
      <div class="congrats-sub"   id="congratsSub">added to your input</div>
    </div>
  </div>

  <script src="js/confetti.js"></script>
  <script src="js/plinko.js"></script>
  <script src="js/chaos.js"></script>
  <script src="js/fields.js"></script>
  <script src="js/ui.js"></script>
  <script src="js/main.js"></script>

<?php endif; ?>

</body>
</html>